import 'package:flutter/material.dart';
import 'package:flutter_chess_board/flutter_chess_board.dart';

void main() {
  runApp(const ChessManiaApp());
}

class ChessManiaApp extends StatefulWidget {
  const ChessManiaApp({Key? key}) : super(key: key);

  @override
  State<ChessManiaApp> createState() => _ChessManiaAppState();
}

class _ChessManiaAppState extends State<ChessManiaApp> {
  ThemeMode _themeMode = ThemeMode.dark;

  void _toggleTheme() {
    setState(() {
      _themeMode =
          _themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ChessMania',
      debugShowCheckedModeBanner: false,
      themeMode: _themeMode,
      theme: ThemeData.light().copyWith(
        primaryColor: Colors.blue,
        appBarTheme: const AppBarTheme(color: Colors.blue),
      ),
      darkTheme: ThemeData.dark().copyWith(
        primaryColor: Colors.deepPurple,
        appBarTheme: const AppBarTheme(color: Colors.deepPurple),
      ),
      home: ChessHomePage(
        toggleTheme: _toggleTheme,
        themeMode: _themeMode,
      ),
    );
  }
}

class ChessHomePage extends StatefulWidget {
  final VoidCallback toggleTheme;
  final ThemeMode themeMode;

  const ChessHomePage(
      {Key? key, required this.toggleTheme, required this.themeMode})
      : super(key: key);

  @override
  State<ChessHomePage> createState() => _ChessHomePageState();
}

class _ChessHomePageState extends State<ChessHomePage> {
  final ChessBoardController controller = ChessBoardController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ChessMania'),
        actions: [
          IconButton(
            icon: Icon(widget.themeMode == ThemeMode.dark
                ? Icons.light_mode
                : Icons.dark_mode),
            onPressed: widget.toggleTheme,
            tooltip: 'Toggle Dark/Light Mode',
          ),
        ],
      ),
      body: Center(
        child: ChessBoard(
          controller: controller,
          boardColor: widget.themeMode == ThemeMode.dark
              ? BoardColor.brown
              : BoardColor.orange,
          boardOrientation: PlayerColor.white,
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          controller.resetBoard();
        },
        tooltip: 'Reset Board',
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
