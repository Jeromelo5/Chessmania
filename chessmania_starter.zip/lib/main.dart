import 'package:flutter/material.dart';

void main() {
  runApp(const ChessManiaApp());
}

class ChessManiaApp extends StatelessWidget {
  const ChessManiaApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ChessMania',
      theme: ThemeData.dark(),
      home: const Scaffold(
        appBar: AppBar(title: Text('ChessMania by Jerome Vincent Loggenberg')),
        body: Center(child: Text('Welcome to ChessMania! Chess board here.')),
      ),
    );
  }
}
