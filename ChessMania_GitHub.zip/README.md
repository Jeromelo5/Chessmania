# ChessMania

ChessMania is a beautiful Flutter chess app featuring:

- Dark and Light mode toggle
- Easy-to-use chessboard interface
- Reset button to start fresh
- Custom app icon
- Developer: Jerome Vincent Loggenberg

## Getting Started

1. Make sure you have Flutter installed: https://flutter.dev/docs/get-started/install
2. Clone this repo
3. Run `flutter pub get`
4. Run `flutter run`
