
import 'package:flutter/material.dart';

void main() {
  runApp(ChessManiaApp());
}

class ChessManiaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark(),
      home: Scaffold(
        appBar: AppBar(title: Text("ChessMania")),
        body: Center(child: Text("Welcome to ChessMania!")),
      ),
    );
  }
}
